# HTTP Explained — IT 3203 Web Development Milestone #1

**Student:** Bryson Mitchell  
**Course:** IT 3203 — Kennesaw State University  
**Research topic:** HTTP and the Evolution of Web Communication (adapted from Assignment #1)

## Website structure

| File | Purpose |
| --- | --- |
| `index.html` | Homepage, introduction, key terms, and table of contents |
| `how-http-works.html` | First research topic page: the request/response cycle |
| `evolution.html` | Second research topic page: HTTP version history |
| `https-security.html` | Third topic page: HTTPS, encryption, and security |
| `key-concepts.html` | Definitions for seven important terms |
| `references.html` | Research references and learning resources |
| `about.html` | Student mini-resume and project description |
| `styles.css` | **Only** stylesheet, shared by all pages |
| `assets/*.svg` | Original local SVG illustrations and favicon |

## How to preview

Open `index.html` with a browser; the relative links work locally. You can also use Visual Studio Code's Live Server if you have it.

## How to publish to GitHub Pages

1. Sign in to GitHub and create a **public repository** named `http-explained` (or another unique project name).
2. Upload all **individual files and the `assets` folder** to the repository's root. Don't upload only the ZIP file.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose the **main** branch and **/(root)** folder, and save.
5. When GitHub finishes publishing, click **Visit site** in the Pages settings. A project website usually has this structure: `https://YOUR-USERNAME.github.io/http-explained/` (replace the placeholder with your own username and repository name).
6. Check that each navigation link, image, and external resource opens on the live site before submitting its actual URL.

## HTML validation

1. Open https://validator.w3.org/nu/ and switch to **File Upload** (or use the live URL after publishing).
2. Check each of the seven `.html` files individually.
3. Fix any errors, republish, and validate the public site again.

## Milestone #1 requirements checked in the source

- Seven pages; at least two topic pages; common site navigation; homepage table of contents.
- References/resources, seven key concepts, and About page.
- Semantic headings, lists, SVG images, captions, and tables.
- Exactly one linked CSS file, responsive Grid and Flexbox, and element/class/ID selectors.
- Link hover styling, borders, padding, margin, text/background colors, typography.
- Class-project notice and official course link in every footer.
- Commented HTML and CSS.

**Important:** The HTML pages are prepared for publication, but the ZIP itself does not publish the website. GitHub Pages deployment and final online validation require a live GitHub repository. Review the site and make any edits required by the full Project General Guide or your instructor.
